import tkinter
import matplotlib
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import sympy
def graph(text):
    win = tkinter.Tk()
    win.iconbitmap('Icons/Functions_Icon_ico.ico')
    win.geometry('700x350')
    win.title('Functions: LaTeX formula output')
    can_k = tkinter.Canvas(width=700, height=350)
    can_k.pack()
    label = tkinter.Label(can_k)
    label.pack()
    fig = matplotlib.figure.Figure(figsize=(7, 4), dpi=100)
    wind = fig.add_subplot(111)
    canvas = FigureCanvasTkAgg(fig, master=label)
    canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)
    canvas._tkcanvas.pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)
    wind.get_xaxis().set_visible(False)
    wind.get_yaxis().set_visible(False)
    win.bind('<Return>', graph)
    tmptext = '$' + sympy.latex(sympy.sympify(text)) + '$'
    wind.clear()
    wind.text(0.2, 0.6, tmptext, fontsize = 20)
    canvas.draw()
    win.mainloop()